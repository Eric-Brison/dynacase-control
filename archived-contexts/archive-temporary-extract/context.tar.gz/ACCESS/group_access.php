<?php
/**
 * Generated Header (not documented yet)
 *
 * @author Anakeen 2000 
 * @version $Id: group_access.php,v 1.2 2003/08/18 15:46:41 eric Exp $
 * @license http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License
 * @package WHAT
 * @subpackage ACCESS
 */
 /**
 */

// ---------------------------------------------------------------
// $Id: group_access.php,v 1.2 2003/08/18 15:46:41 eric Exp $
// $Source: /home/cvsroot/anakeen/freedom/core/Action/Access/group_access.php,v $
// ---------------------------------------------------------------
// $Log: group_access.php,v $
// Revision 1.2  2003/08/18 15:46:41  eric
// phpdoc
//
// Revision 1.1  2002/01/08 12:41:33  eric
// first
//
// Revision 1.1  2001/09/07 16:52:01  eric
// gestion des droits sur les objets
//

// ---------------------------------------------------------------

include_once("ACCESS/user_access.php");

// -----------------------------------
function group_access(&$action) {
// -----------------------------------
  user_access($action, true);
}

  



?>
