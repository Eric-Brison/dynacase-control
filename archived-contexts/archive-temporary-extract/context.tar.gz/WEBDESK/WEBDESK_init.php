<?php

/**
 * @author Anakeen
 * @license http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License
 */

// ---------------------------------------------------------------
// $Id: WEBDESK_init.php.in,v 1.8 2008/12/12 10:51:36 marc Exp $
// $Source: /home/cvsroot/anakeen/freedom/webdesk/WEBDESK_init.php.in,v $
// ---------------------------------------------------------------

global $app_const;

$app_const = 
array(
  
"VERSION" => "1.2.0-6",
"INIT" => "yes",

"WDK_PORTALSPEC" => array( "val"=>"d&eacute;faut|33:33:33", "descr"=>N_("portal colums specification"), "user"=>"Y", "kind"=> "static"),
"WDK_DEFAPP" => array( "val"=>"WEBDESK", "descr"=>N_("default application displayed"),"user"=>"Y", "kind"=>"text"),
"WDK_COLCOUNT" => array( "val"=>"3", "descr"=>N_("portal columns count"),"user"=>"Y"),
"WDK_SVCCOLCOUNT" => array( "val"=>"3", "descr"=>N_("services list columns count"),"user"=>"Y"),
"ARDOISE" => array( "val"=>"", "descr"=>N_("ardoise content"),"user"=>"Y", "kind"=>"static"),
"WDK_BARAPP" => array( "val"=>"", "descr"=>N_("application present in application bar"),"user"=>"Y", "kind"=>"static"),

"WDESK_MENUCOLOR" => array( "val"=>"", 
			    "descr"=>N_("webdesk menu background color"),
			    "user"=>"N",
			    "kind"=>"color",
			    "style"=>"N",
			    "global"=>"N"),
"WDESK_MENUIMAGE" => array( "val"=>"", 
			    "descr"=>N_("webdesk menu background image"),
			    "user"=>"N",
			    "style"=>"N",
			    "global"=>"N"),
"WDESK_MENUIMGW" => array( "val"=>"15", 
			    "descr"=>N_("webdesk menu background image width"),
			    "user"=>"N",
			    "style"=>"N",
			    "global"=>"N"),
);

?>
