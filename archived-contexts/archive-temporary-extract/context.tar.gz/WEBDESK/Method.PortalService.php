// $Id: Method.PortalService.php,v 1.2 2006/11/18 14:43:31 marc Exp $
// No method defined
