<?php

$lang["en_US"] = array(
		       "label"  => "English",
		       "locale" => "en"
		       );

?>