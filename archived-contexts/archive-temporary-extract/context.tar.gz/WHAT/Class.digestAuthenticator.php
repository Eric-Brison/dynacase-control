<?php

/**
 * digestAuthenticator class
 *
 * !!! TODO !!!
 * This class provides methods for HTTP Digest authentication
 * !!! TODO !!!
 *
 * @author Anakeen 2009
 * @version $Id: Class.digestAuthenticator.php,v 1.2 2009/01/16 13:33:00 jerome Exp $
 * @license http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License
 * @package WHAT
 * @subpackage
 */
 /**
 */

Class digestAuthenticator {
  function __construct($parms) {
    throw new Exception(__CLASS__."::".__FUNCTION__." "."Not available yet...");
  }

}

?>
