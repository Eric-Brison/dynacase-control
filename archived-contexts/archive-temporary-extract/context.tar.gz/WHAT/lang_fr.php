<?php

$lang["fr_FR"] = array(
		       "label"  => "Français",
		       "flag"   => "",
		       "locale" => "fr"
		       );

?>