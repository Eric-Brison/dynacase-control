<?php
/**
 * Viem bar menu for generic application
 *
 * @author Anakeen 2000 
 * @version $Id: generic_barmenu.php,v 1.10 2006/02/03 17:03:41 eric Exp $
 * @license http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License
 * @package FREEDOM
 * @subpackage 
 */
 /**
 */


include_once("GENERIC/barmenu.php");  

// -----------------------------------
function generic_barmenu(&$action) {
  // -----------------------------------
  
  barmenu($action);
}



?>
